// console.log( wp );
import block_icons from '../icons/index';//importing icons
import './editor.scss';//importing scss file

const { registerBlockType }             =   wp.blocks;
const { __ }                            =   wp.i18n;//internalization translatable
const { InspectorControls,
        BlockControls,
        AlignmentToolbar,
        BlockAlignmentToolbar }         =   wp.editor;//adding the ability to add editor block into gutenberg
const { PanelBody, PanelRow, 
        TextControl, SelectControl }    =   wp.components;//adding panel to the sidebar for the blocks editor

//wp.blocks.registerBlockType( name:String, typeDefinition: Object )
//use to create blocks in gutenberg
registerBlockType( 'udemy/recipe', {
    title:              __( 'Recipe', 'recipe' ),//i18n = internationalization
    description:        __( 
        'Provides a short summary of a recipe.',
        'recipe'
    ),
    //category our common, formatting, layout, widgets, embed
    category:           'common',
    icon:               block_icons.wapuu,
    keywords:   [
        __( 'Food', 'recipe' ),
        __( 'Ingredients', 'recipe' ),
        __( 'Meal Type', 'recipe' )
    ],
    supports: {
        html:           false
    },
    attributes: {
        ingredients:{
            type:               'string',//type- setting the data type 
            source:             'text',//source- use to instruct gutenberg what to extract from the HTML in the database
            selector:           '.ingredients-ph'//selector-instruct the gutenberg where the data can be found inside the html
        },
        cooking_time:{
            type:               'string',
            source:             'text',
            selector:           '.cooking-time-ph'
        },
        utensils:{
            type:               'string',
            source:             'text',
            selector:           '.utensils-ph'
        },
        cooking_experience:{
            type:               'string',
            source:             'text',
            selector:           '.cooking-experience-ph',
            default:            'Beginner'
        },
        meal_type:{
            type:               'string',
            source:             'text',
            selector:           '.meal-type-ph',
            default:            'Breakfast'
        },
        text_alignment: {//adding text alignment tool
            type:               'string'
        },
        block_alignment: {//adding block alignment tool
            type:               'string',
            default:            'wide'
        }
    },
    //geteditwrapperprops this will automatically triggered where's there a change in block
    //can access directly the attributes properties
    getEditWrapperProps: ( { block_alignment } ) => {
        if( 'left' === block_alignment || 'right' === block_alignment || 'full' === block_alignment ){
            return { 'data-align':  block_alignment };
        }
    },
    edit:   ( props ) => {//this is use to have an editor field inside gutenberg
        // console.log( props );
        //other way around
        // const updateIngredients =   ( new_val )=>{
        //     props.setAttributes( { ingredients: new_val } )
        // }

        // const updateCookingtime =   ( new_val )=>{
        //     props.setAttributes( { cooking_time: new_val })
        // }

        // const updateUtensils =   ( new_val )=>{
        //     props.setAttributes( { utensils: new_val } )
        // }
        
        return [
            //this will create input field on the sidebar of the gutenberg for the blocks
            <InspectorControls>
                <PanelBody title={ __( 'Basics', 'recipe' ) }>
                    <PanelRow>
                        <p>{ __( 'Configure the contents of your block here', 'recipe' )  }</p>
                    </PanelRow>

                    <TextControl 
                        label={ __( 'Ingredients', 'recipe' )}
                        help={ __( 'Ex: tomatoes, lettuce, olive oil, etc.', 'recipe' ) }
                        value={ props.attributes.ingredients }
                        onChange={ ( new_val )=>{
                            props.setAttributes( { ingredients: new_val } )
                        }}
                    />

                    <TextControl 
                        label={ __( 'Cooking Time', 'recipe' )}
                        help={ __( 'How long will this take to cook?', 'recipe' ) }
                        value={ props.attributes.cooking_time }
                        onChange={ ( new_val )=>{
                            props.setAttributes( { cooking_time: new_val } )
                        }}
                        
                    />

                    <TextControl 
                        label={ __( 'Utensils', 'recipe' )}
                        help={ __( 'Ex: spoon, knife, pots, pans', 'recipe' ) }
                        value={ props.attributes.utensils }
                        onChange={ ( new_val )=>{
                            props.setAttributes( { utensils: new_val } )
                        }}
                    />

                    <SelectControl
                        label={ __( 'Cooking Experience', 'recipe' )}
                        help={ __( 'How skilled should be the reader be?', 'recipe' ) }
                        value={ props.attributes.cooking_experience }
                        options={[
                            { value: 'Beginner', label: 'Beginner' },
                            { value: 'Intermediate', label: 'Intermediate' },
                            { value: 'Expert', label: 'Expert' }
                        ]}
                        onChange={ ( new_val )=>{
                            props.setAttributes( { cooking_experience: new_val } )
                        }}
                    />

                    <SelectControl
                        label={ __( 'Meal Type', 'recipe' )}
                        help={ __( 'When is this best eaten', 'recipe' ) }
                        value={ props.attributes.meal_type }
                        options={[
                            { value: 'Breakfast', label: 'Breakfast' },
                            { value: 'Lunch', label: 'Lunch' },
                            { value: 'Dinner', label: 'Dinner' }
                        ]}
                        onChange={ ( new_val )=>{
                            props.setAttributes( { meal_type: new_val } )
                        }}
                    />
                </PanelBody>
            </InspectorControls>,
            //this is the html we can see inside the gutenbeg editor field
            //className - is the attribute to put CSS classes in a JSX 
            //this CSS classes use to find by the attributes selector and put it in the front end
            //block controls use to add toolbar on every block editor
            <div className={ props.className }>
                <BlockControls>
                    <BlockAlignmentToolbar
                        value={ props.attributes.block_alignment }
                        onChange={ (new_val )=>{
                            props.setAttributes( { block_alignment: new_val } );
                        }}
                    />
                    <AlignmentToolbar
                        value={ props.attributes.text_alignment }
                        onChange={ (new_val )=>{
                            props.setAttributes( { text_alignment: new_val } );
                        }}   
                    />
                </BlockControls>
                <ul className="list-unstyled"
                    style={ { textAlign: props.attributes.text_alignment } }>
                    <li>
                        <strong>{ __( 'Ingredients', 'recipe' ) }: </strong>
                        <span className="ingredients-ph">{ props.attributes.ingredients }</span>
                    </li>
                    <li>
                        <strong>{ __( 'Cooking Time', 'recipe' ) }: </strong> 
                        <span className="cooking-time-ph">{ props.attributes.cooking_time }</span>
                    </li>
                    <li>
                        <strong>{ __( 'Utensils', 'recipe' ) }: </strong> 
                        <span className="utensils-ph">{ props.attributes.utensils }</span>
                    </li>
                    <li>
                        <strong>{ __( 'Cooking Experience', 'recipe' ) }: </strong> 
                        <span className="cooking-experience-ph">{ props.attributes.cooking_experience }</span>
                    </li>
                    <li>
                        <strong>{ __( 'Meal Type', 'recipe') }: </strong> 
                        <span className="meal-type-ph">{ props.attributes.meal_type }</span>
                    </li>
                </ul>
            </div>
        ];
    },
    save:   ( props )=> {//this is use to save on the database and show in the front end
        return (
            <div className={`align${props.attributes.block_alignment}`}>
                <ul className="list-unstyled"
                style={ { textAlign: props.attributes.text_alignment } }>
                    <li>
                        <strong>{ __( 'Ingredients', 'recipe' ) }: </strong>
                        <span className="ingredients-ph">{ props.attributes.ingredients }</span>
                    </li>
                    <li>
                        <strong>{ __( 'Cooking Time', 'recipe' ) }: </strong> 
                        <span className="cooking-time-ph">{ props.attributes.cooking_time }</span>
                    </li>
                    <li>
                        <strong>{ __( 'Utensils', 'recipe' ) }: </strong> 
                        <span className="utensils-ph">{ props.attributes.utensils }</span>
                    </li>
                    <li>
                        <strong>{ __( 'Cooking Experience', 'recipe' ) }: </strong> 
                        <span className="cooking-experience-ph">{ props.attributes.cooking_experience }</span>
                    </li>
                    <li>
                        <strong>{ __( 'Meal Type', 'recipe') }: </strong> 
                        <span className="meal-type-ph">{ props.attributes.meal_type }</span>
                    </li>
                </ul>
            </div>
        )
    }
});