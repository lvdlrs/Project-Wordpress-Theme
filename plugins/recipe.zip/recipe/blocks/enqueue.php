<?php

function r_enqueue_block_editor_assets(){
    wp_register_script(
        'r_blocks_bundle',
        plugins_url( '/blocks/dist/bundle.js', RECIPE_PLUGIN_URL ),
        //wp-i18n, use to translate, 
        //wp-element use to convert jsx to js functions, 
        //wp-blocks allows us to register our blocks interact with Gutenburg
        //wp-components some of gutenburg components that can be reuse with our own scripts
        //wp-editor comes with tools & functions related to editor, that will help us create a more consistent user experience when building our blocks
        //wp-api able us to connect with WP REST API
        [ 'wp-i18n', 'wp-element', 'wp-blocks', 'wp-components', 'wp-editor', 'wp-api'],
        filemtime( plugin_dir_path( RECIPE_PLUGIN_URL ) . '/blocks/dist/bundle.js'  )
    );
    wp_enqueue_script( 'r_blocks_bundle' );
}

function r_enqueue_block_assets(){
    wp_register_style(
      'r_blocks',
      plugins_url( '/blocks/dist/block-main.css', RECIPE_PLUGIN_URL )  
    );

    wp_register_style(
        'r_google_fonts',
        'https://fonts.googleapis.com/css?family=Lato&display=swap',
        []
    );

    wp_enqueue_style( 'r_google_fonts' );
    wp_enqueue_style( 'r_blocks' );
}