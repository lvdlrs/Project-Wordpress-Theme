<?php

//this uses to save post

function r_save_post_admin( $post_id, $post, $update ){
    $recipe_data            =   get_post_meta( $post_id, 'recipe_data', true );
    // checking of the variable if empty using ternary operators 
    // if empty($recipe_data) = true, set status $recipe_data = [] (empty array)
    // if empty($recipe_data) = false, set status $recipe_data = $recipe_data
    $recipe_data            =   empty( $recipe_data ) ? [] : $recipe_data;
    //storing the rating and how many times it rated
    //$recipe_data['rating'] -> storing the rating
    //  value is equal to checking if the rating is set, absint (use for sanitizing value)
    // isset use to check if a variable is declared
    $recipe_data['rating']  =   isset($recipe_data['rating']) ? absint($recipe_data['rating']) : 0;
    //checking rating count
    $recipe_data['rating_count']  =   isset($recipe_data['rating_count']) ? absint($recipe_data['rating_count']) : 0;

    update_post_meta( $post_id, 'recipe_data', $recipe_data );
}