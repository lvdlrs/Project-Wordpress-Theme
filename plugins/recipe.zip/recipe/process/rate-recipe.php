<?php

function r_rate_recipe(){
    // print_r($_POST);//use to outputted or test if the ajax send into the browser
    global $wpdb;

    $output                 =   [ 'status'  => 1 ];//array use to handle responses

    $recipe_option          =   get_option( 'r_opts' );
    if( !is_user_logged_in() && $recipe_option[ 'rating_login_required' ] == 2 ){
        wp_send_json($output);
    }

    $post_ID                =   absint( $_POST['rid'] );
    $rating                 =   round( $_POST['rating'], 1);//use to round up
    $user_IP                =   $_SERVER['REMOTE_ADDR'];//use to get user IP address

    //Getting values from the database and checking it
    $rating_count           =   $wpdb->get_var(//set to return the value get from the database
        "SELECT COUNT(*) FROM `" . $wpdb->prefix . "recipe_ratings`
        WHERE recipe_id = '" . $post_ID . "' AND user_ip = '" . $user_IP . "'"
    );
    //use to check if row count is greater than 0
    if( $rating_count > 0){
        wp_send_json( $output );
    }
    //inserting rating to database
    $wpdb->insert(//$wpdb->insert( $table, $data, $format )
        $wpdb->prefix . 'recipe_ratings',
        [
            'recipe_id'     =>   $post_ID,
            'rating'        =>   $rating,
            'user_ip'       =>   $user_IP
        ],
        //%d = integer, %f= float is a number with decimal point, %string
        //this is an array use to format the data in the table
        [ '%d', '%f', '%s' ]
    );
    //this data use to average the ratings on sign
    //update Recipe metadata
    $recipe_data             = get_post_meta( $post_ID, 'recipe_data', true );
    $recipe_data['rating_count']++;
    $recipe_data['rating']  =   round($wpdb->get_var(
        "SELECT AVG(`rating`) FROM `" . $wpdb->prefix . "recipe_ratings`
        WHERE recipe_id='" . $post_ID . "'"
    ), 1);  

    update_post_meta( $post_ID, 'recipe_data', $recipe_data );

    do_action( 'recipe_rated', [
        'post_id'               =>  $post_ID,
        'rating'                =>  $rating_count,
        'user_IP'               =>  $user_IP
    ]);

    $output['status']        =   2; //1 on the top means the sending is a failure and 2 means it is a success
    wp_send_json( $output );//wp_send_json() will JSON encode the array and kill the request
    
}