<?php

//$items -> which is the raw html menu items
function ju_new_nav_menu_items( $items ){
    //this will use to check if the user is not logged in
    if( !is_user_logged_in() ){
        return $items;
    }
    //this will use if the user is logged in to display the logged out link
    //wp_loginout( url to redirect after login/logout, to echo and not return the link(BOOL) )
    $new_link           =   "<li>" . wp_loginout( home_url( '/ '), false ) . "</li>"; 

    return $items . $new_link;
}