<?php

function r_dashboard_widgets(){
    /*wp_add_dashboard_widget( slug ID, 
      title of the widgets, function to call that will display the widgets)*/
    wp_add_dashboard_widget(
        'r_latest_recipe_rating_widgets',
        'Latest Recipe Ratings',
        'r_latest_recipe_rating_display'
    );
}

function r_latest_recipe_rating_display(){
    global $wpdb;
    //getting the latest_ratings by ordering it by their OD and limit it to 5
    $latest_ratings     =   $wpdb->get_results(
        "SELECT * FROM `" . $wpdb->prefix . "recipe_ratings` ORDER BY `ID` DESC LIMIT 5"
    );

    echo '<ul>';

    foreach($latest_ratings as $rating){
        $title          =   get_the_title( $rating->recipe_id );
        $permalink      =   get_the_permalink( $rating->recipe_id );

        ?>

        <li>
            <a href="<?php echo $permalink; ?>"><?php echo $title; ?></a>
            received a rating of <?php echo $rating->rating; ?>
        </li>

        <?php
    }


    echo '</ul>';
}