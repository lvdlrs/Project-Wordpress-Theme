<?php

function r_load_textdomain(){
    $plugin_dir             =   'recipe/lang';
    /**
     * load_plugin_textdomain( 
     *  name of your plugin(textdomain),
     *  deprecated must be false,
     *  location to the translation
     * )
     */
    load_plugin_textdomain( 'recipe', false, $plugin_dir );
}