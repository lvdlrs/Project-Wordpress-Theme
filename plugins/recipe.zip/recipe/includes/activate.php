<?php

function r_activate_plugin(){
    //use to check for wordpress version and it only works on the wordpress version indicated
    //5.8 < 5.0
    if( version_compare( get_bloginfo( 'version' ), '5.0', '<' ) ){
        wp_die( "You must update Wordpress to use this plugin.", 'recipe' );
    }

    recipe_init();
    flush_rewrite_rules();

    //use to create custom query in SQL database
    global $wpdb;

    //$wpdb->prefix is a propery inside the $wpdb use to add the installation prefix of database
    $createSQL      =   
    " CREATE TABLE `" . $wpdb->prefix . "recipe_ratings` (
        `ID` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        `recipe_id` BIGINT(20) UNSIGNED NOT NULL,
        `rating` FLOAT(3,2) UNSIGNED NOT NULL,
        `user_ip` VARCHAR(50) NOT NULL,
        PRIMARY KEY (`ID`)
    )
    ENGINE=InnoDB " . $wpdb->get_charset_collate() .";";//use to get the current database collation

    //the constant ABSPATH is created by WP and points to the root installation of our wordpress site
    // this is use to able to use the function dbDelta
    require( ABSPATH . "/wp-admin/includes/upgrade.php" );
    dbDelta( $createSQL ); // use to execute query that modifies database

    wp_schedule_event( time(), 'daily', 'r_daily_recipe_hook' );//creating cron jobs that will give daily ra

    $recipe_opts                                =   get_option( 'r_opts' );//this will retrieve the value of the options

    if( !$recipe_opts ){
        $opts                                   =   [
            'rating_login_require'              =>  1,
            'recipe_submission_login_required'  =>  1
        ];
        
        //add_option( name of the options, options value )
        add_option( 'r_opts', $opts );
    }

    global $wp_roles;
    add_role(
        'recipe_author',//role name(ID)
        __( 'Recipe Author', 'recipe' ),//Readable name of the ROle
        [//3rd param, list of capabilities the role have
            'read'          => true,
            'edit_posts'    => true,
            'upload_files'  => true
        ]
    );

}