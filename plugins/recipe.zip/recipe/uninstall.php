<?php
//this file use to uninstall the plugin and remove the data from the database

//this use to check if the wp_uninstall_plugin file is define by the wordpress
if( !defined( 'WP_UNINSTALL_PLUGIN' ) ){
    exit;
};

global $wpdb;

$wpdb->query("DROP TABLE IF EXISTS `" . $wpdb->prefix . "recipe_ratings `" );