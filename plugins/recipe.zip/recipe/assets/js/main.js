(function($){

    //this called when user rate an object
    $( "#recipe_rating" ).bind( 'rated', function(){
        $(this).rateit( 'readonly', true );//this method allows us to change this property
        //setting the readonly properties to true this prevent the user to change its rating after rated the recipe
        
        var form    =   {//creating object as form use to send an AJAX request
            action:     'r_rate_recipe',//use to deternmine what action to use when ajax request
            rid:        $(this).data( 'rid' ),//
            rating:     $(this).rateit( 'value' )//this will return its rating
        };

        //recipe_obj is the ID of the object that created in the localize function
        //form is the object created above
        $.post( recipe_obj.ajax_url, form, function(data){

        });

    });

    // https://codex.wordpress.org/Javascript_Reference/wp.media
    var feature_frame                       =   wp.media({
        title:                                  'Select or Upload Media',
        button:{
            text:                               'Use this media'
        },
        multiple:                                false
    });

    feature_frame.on( 'select', function(){
        var attachment                       =  feature_frame.state().get('selection').first().toJSON();
        $("#recipe-img-preview").attr( 'src', attachment.url );
        $("#r_inputImgID").val( attachment.id );
    });

    $(document).on( 'click', '#recipe-img-upload-btn', function(e){
        e.preventDefault();

        feature_frame.open();
    });

    $( "#recipe-form").on( 'submit', function(e){
        e.preventDefault();

        $(this).hide();

        $( "#recipe-status" ).html(
            '<div class="alert alert-info">Please wait! We are submitting your recipe.</div>'
        );

        var form            =   {
            action:             'r_submit_user_recipe',
            title:              $( "#r_inputTitle" ).val(),
            content:            tinymce.activeEditor.getContent(),
            attachment_id:      $("#r_inputImgID").val()
        }

        $.post( recipe_obj.ajax_url, form, function(data){
            if( data.status == 2 ){
                $( "#recipe-status" ).html(
                    '<div class="alert alert-success">Recipe submitted successfully.</div>'
                );
            } else{
                $( "#recipe-status" ).html(
                    '<div class="alert alert-danger">Unable to submit recipe. Please fill in all fields.</div>'
                );
                $( "#recipe-form" ).show();
            }
        });

    });

    $(document).on( 'submit', '#register-form', function(e){
        e.preventDefault();

        $('#register-status').html(
            '<div class="alert alert-info">Please, wait!</div>'
        );
        $(this).hide();

        var form                         =   {
            _wpnonce:                        $("#_wpnonce").val(),
            action:                          "recipe_create_account",
            name:                            $("#register-form-name").val(),
            username:                        $("#register-form-username").val(),
            email:                           $("#register-form-email").val(),
            pass:                            $("#register-form-password").val(),
            confirm_pass:                    $("#register-form-repassword").val()
        };

        $.post( recipe_obj.ajax_url, form ).always(function(data){
            if( data.status == 2 ){
                $( "#register-status" ).html(
                    '<div class="alert alert-success">Account Created!</div>'
                );
                location.href              =    recipe_obj.home_url;
            } else{
                $( "#register-status" ).html(
                    '<div class="alert alert-danger">Unable to create an account.</div>'
                );
                $( "#register-form" ).show();
            }
        });
    });

    $(document).on( 'submit', '#login-form', function(e){
        e.preventDefault();

        $('#login-status').html(
            '<div class="alert alert-info">Please wait while we log you in.</div>'
        );
        $(this).hide();

        var form                         =   {
            _wpnonce:                        $("#_wpnonce").val(),
            action:                          "recipe_user_login",
            username:                        $("#login-form-username").val(),
            pass:                            $("#login-form-password").val(),
        };

        $.post( recipe_obj.ajax_url, form ).always(function(data){
            if( data.status == 2 ){
                $( "#login-status" ).html(
                    '<div class="alert alert-success">Login Success!</div>'
                );
                location.href              =    recipe_obj.home_url;
            } else{
                $( "#login-status" ).html(
                    '<div class="alert alert-danger">Unable to login.</div>'
                );
                $( "#login-form" ).show();
            }
        });
    })
    
})(jQuery);