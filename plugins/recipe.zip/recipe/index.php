<?php
/*
 *  Plugin Name: Recipe
 *  Description: A simple Wordpress plugin that allows user to create recipes and rate those recipes
 *  Version: 1.0
 *  Author: Lenmuel V. Del Rosario
 *  Author URI: https://www.lenmueldlrs.com
 *  Text Domain: recipe 
 */
 //use for security to avoid loading unncessary scripts
 //wordpress loads first its files before loading plugins if the this function doesn't exist
 // the wp is not yet loaded and the unneccsary scripts will not load.
 if( !function_exists( 'add_action' ) ){
     echo "Hi There! I'm just a plugin not much I can do when called directly.";
     exit;
 }

 //Setup
 define( 'RECIPE_PLUGIN_URL', __FILE__ );//use to referencing plugin file when enqueueing our files

 //Includes
 include( 'includes/activate.php' );
 include( 'includes/init.php' );
 include( 'process/save-post.php' );
 include( 'process/filter-content.php' );
 include( 'includes/front/enqueue.php');
 include( 'process/rate-recipe.php' );
 include( 'includes/admin/init.php');
 include( 'blocks/enqueue.php' );
 include( dirname(RECIPE_PLUGIN_URL) . '/includes/widgets.php' );
 include( 'includes/widgets/daily-recipe.php' );
 include( 'includes/cron.php' );
 include( 'includes/deactivate.php' );
 include( 'includes/utility.php' );
 include( 'includes/shortcodes/creator.php' );
 include( 'process/submit-user-recipe.php' ); 
 include( 'includes/shortcodes/auth-form.php' );
 include( 'process/create-account.php' ); 
 include( 'process/login.php' );
 include( 'includes/shortcodes/auth-alt-form.php' ); 
 include( 'includes/front/logout-link.php' );
 include( 'includes/admin/dashboard-widgets.php' );
 include( 'includes/shortcodes/twitter-follow.php' );
 include( 'includes/admin/menus.php' );
 include( 'includes/admin/options-page.php' );
 include( 'process/save-options.php' );
 include( 'includes/admin/origin-fields.php' );
 include( 'process/save-origin.php' );
 include( 'includes/notice.php' );
 include( 'process/remove-notice.php');
 include( 'includes/textdomain.php' );


 //Hooks
 register_activation_hook( __FILE__, 'r_activate_plugin' );
 register_deactivation_hook( __FILE__, 'r_deactivate_plugin' );
 add_action( 'init', 'recipe_init' );
 add_action( 'save_post_recipe', 'r_save_post_admin', 10, 3 );
 add_filter( 'the_content', 'r_filter_recipe_content' );
 add_action( 'wp_enqueue_scripts', 'r_enqueue_scripts', 100 );//100 priority to load last
 add_action( 'wp_ajax_r_rate_recipe', 'r_rate_recipe' );//wp_ajax +$your action
 add_action( 'wp_ajax_nopriv_r_rate_recipe', 'r_rate_recipe' );//wp_ajax +$your action
 add_action( 'admin_init', 'recipe_admin_init' );//this allow to customize the display in the admin dashboard.
 add_action( 'enqueue_block_editor_assets', 'r_enqueue_block_editor_assets');//use to customize gutenburg blocks on admin side
 add_action( 'enqueue_block_assets', 'r_enqueue_block_assets' );//this hook is triggered when the editor is loaded or page on the front is viewed, this is use to match the styling on the editor to the front end page
 add_action( 'widgets_init', 'r_widgets_init' );//this hook is called when widget's are initialize
 add_action( 'r_daily_recipe_hook', 'r_generated_daily_recipe' );
 add_action( 'wp_ajax_r_submit_user_recipe', 'r_submit_user_recipe' );//ajax for submitting user recipe
 add_action( 'wp_ajax_nopriv_r_submit_user_recipe', 'r_submit_user_recipe' );//ajax for submitting user recipe by no privilege (no need to sign in to send a user recipe)
 add_action( 'wp_ajax_nopriv_recipe_create_account', 'recipe_create_account' );// ajax for registration for new account
 add_action( 'wp_ajax_nopriv_recipe_user_login', 'recipe_user_login' );// ajax for login 
 //add_filter( 'authenticate', 'wp_authenticate_username_password', 20, 3 );
 //add_filter( 'authenticate', 'wp_authenticate_spam_check', 99 );
//  add_filter( 'authenticate', 'r_alt_authenticate', 100, 3 ); // use for authentication
 add_filter( 'wp_nav_menu_secondary_items', 'ju_new_nav_menu_items', 999 );//this will trigger after wordpress theme navigation is loaded (wp_nav_menu_secondary_items use to place the logout link as secondary)
 add_filter( 'wp_dashboard_setup', 'r_dashboard_widgets' ); // this will add widgets in the wp admin dashboard
 add_action( 'admin_menu', 'r_admin_menus' );//adding menus on the sidebar of the admin
 add_action( 'origin_add_form_fields', 'r_origin_add_form_fields' );//adding additional form field in custom taxonomies
 add_action( 'origin_edit_form_fields', 'r_origin_edit_form_fields' );//enabling to edit form field in custom taxonomies
 add_action( 'create_origin', 'r_save_origin_meta' );//this will create_ taxonomy function - creating taxonomy/updating
 add_action( 'edited_origin', 'r_save_origin_meta' );//this will edit taxonomy(this will use to update the url taxonomy)
 add_action( 'admin_notices', 'r_admin_notices' );//this will provide admin notice in the dashboard for our plugins for a certain condition
 add_action( 'wp_ajax_r_dismiss_pending_recipe_notice', 'r_dismiss_pending_recipe_notice' );
 add_action( 'plugins_loaded', 'r_load_textdomain' );//this will load and tell wordpress that our plugin is ready for translation

 //Shortcodes 
 add_shortcode( 'recipe_creator', 'r_recipe_creator_shortcode' );
 add_shortcode( 'recipe_auth_form', 'r_recipe_auth_form_shortcode' );
//  add_shortcode( 'recipe_auth_alt_form', 'r_recipe_auth_alt_form_shortcode' );
 add_shortcode( 'twitter_follow', 'r_twitter_follow_shortcode');